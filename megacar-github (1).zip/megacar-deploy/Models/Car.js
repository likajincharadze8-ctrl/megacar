const mongoose = require('mongoose');

// Sub-document for uploaded documents (title, customs papers, etc.)
const documentSchema = new mongoose.Schema(
  {
    originalName: { type: String },
    filename: { type: String },
  },
  { _id: false }
);

const carSchema = new mongoose.Schema(
  {
    // Core
    makeModel: { type: String, required: true },
    vin: { type: String, required: true },
    dealerId: { type: String, required: true }, // stores the dealer's username

    // Prices (USD)
    auctionPrice: { type: Number, default: 0 },
    transportPrice: { type: Number, default: 0 },
    amountPaid: { type: Number, default: 0 },

    // Purchase / auction info
    purchaseDate: { type: String },
    auctionName: { type: String }, // Copart / IAAI / Manheim
    lotNumber: { type: String },
    buyLocation: { type: String },

    // Container / shipping
    containerNumber: { type: String },
    containerCode: { type: String },

    // Recipient (importer of record)
    recipientFirstName: { type: String },
    recipientLastName: { type: String },
    recipientId: { type: String },
    recipientPhone: { type: String },

    // Media & docs
    images: [{ type: String }], // filenames inside /uploads
    documents: [documentSchema],

    // Pipeline
    status: { type: String, default: 'Purchased' },
    isFeatured: { type: Boolean, default: false }, // "Deal of the Day"
  },
  { timestamps: true } // gives createdAt (used for sorting) + updatedAt
);

module.exports = mongoose.model('Car', carSchema);
